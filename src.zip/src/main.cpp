#include "Runtime.hpp"

int main()
{
	Runtime program;
	program.run();
}
